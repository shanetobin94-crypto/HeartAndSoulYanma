Heart & Soul 2.0.0 Custom Pokémon Source Patch
================================================

Base:
  PokemonHnS-Development/pokehns-expansion Release-v2.0.0
  Release commit: aee5f71

This package contains the source/assets modified for the custom Pokémon project.

Implemented in this patch:
- Route 30: one Weedle slot -> Yanma.
- Yanma base stats: 85/85/65/95/65/115 (510 BST).
- Yanma starts with Leech Life + Fly in its level-up learnset.
- Yanma remains Bug/Flying with Speed Boost.
- Fly added to Yanma's potential teachable learnset so the field/HM system can recognize it.
- Yanmega species slot repurposed as Emperor:
  Bug/Dragon, 125/125/90/40/90/80 (550 BST),
  Speed Boost + Multiscale, larger Pokédex metric size.
- National Park daytime: one Weedle slot -> Demoiselle; one Sunkern slot -> Frost Butterfree.
- Demoiselle: Bug/Fairy, 80/30/80/110/100/110 (510 BST),
  Magic Bounce + Speed Boost, special/status-focused learnset.
- Frost Butterfree (Frostfree): Bug/Ice, 70/55/60/100/90/80 (455 BST),
  special/status-focused learnset.
- Custom normal/shiny palettes and matching follower palettes for all three custom entries.
- Starting Lab gift changed to 50 Ultra Balls so the Route 30 Yanma can be caught immediately.

Important:
This is a SOURCE PATCH, not a finished .gba ROM. The current build environment here does not contain
the ARM embedded GCC toolchain required by H&S 2.0.0, so a final ROM build could not be completed here.
The original Release-v2.0.0 source should be used as the base and these files overlaid at their relative paths.

The custom battle sprites currently use the real H&S 2.0 Yanma/Yanmega/Butterfree sprite assets with new palettes.
The follower sprites likewise reuse the corresponding H&S overworld graphics with matching custom palettes.
